use mysql;

drop database if exists webho_db;
drop user if exists webho_user@'%', webho_user@localhost;

flush privileges;
