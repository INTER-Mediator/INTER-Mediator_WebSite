<?php

/*
	SQLite データベースファイルを作成します
	このファイル (makeLiteDB.php) をコマンドライン (ターミナル / コマンドプロンプト) から php で実行します
	例: php makeLiteDB.php
	sqlite3 ツールがインストールされていなくても PHP だけインストールされていれば
	データベースファイルを作成できるように用意したファイルです

	データベースファイル (webho.db) が存在する場合は実行不要、またはデータベースファイルを削除してから実行
*/

require_once ("consts.php");

$db = new SQLite3 (DB_FILE);
$db->exec (
	"create table expenses_memo (".
	"id integer primary key autoincrement,".
	"date text null,".
	"debit text null,".
	"credit text null,".
	"destination text null,".
	"summary text null,".
	"withdraw integer null,".
	"issued integer null default 0,".
	"constraint chk_iss check (issued in (0, 1))".
	")"
);
$db->exec (
	"insert into expenses_memo (date, debit, credit, destination, summary, withdraw, issued) values".
	"('2018-05-17', '旅費交通費', '現金', '公共交通機関', '新小岩<->新宿 @302x2', 604, 1)"
);
$db->exec (
	"insert into expenses_memo (date, debit, credit, destination, summary, withdraw, issued) values".
	"('2018-05-17', '通信費', '現金', '葛飾郵便局', 'レターパックライト', 360, 1)"
);
$db->exec (
	"insert into expenses_memo (date, debit, credit, destination, summary, withdraw, issued) values".
	"('2018-05-17', '旅費交通費', '現金', '公共交通機関', '四ツ木<->浅草 @328x2', 656, 1)"
);

$db->close();

?>
