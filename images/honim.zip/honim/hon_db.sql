set names utf8;

/*
	root またはユーザー､データベースの作成､権限の設定ができるユーザーとしてログインし
	source hon_db.sql
	で実行
*/

use mysql;
drop database if exists webho_db;
drop user if exists webho_user@'%', webho_user@localhost;

create user webho_user@'%' identified with mysql_native_password by 'hello';
create user webho_user@localhost identified with mysql_native_password by 'hello';

create database webho_db;
grant all on webho_db.* to webho_user@'%', webho_user@localhost;
flush privileges;

use webho_db;

create table expenses_memo (
	id		int		not null	auto_increment,
	date		date		null,
	debit		varchar(10)	null,
	credit		varchar(10)	null,
	destination	varchar(20)	null,
	summary		varchar(20)	null,
	withdraw	numeric(8,0)	null,
	issued		tinyint		null	default 0,
	constraint	pk_expm	primary key (id),
	constraint	chk_iss	check (issued in (0, 1))
) ENGINE=InnoDB;

insert into expenses_memo (date, debit, credit, destination, summary, withdraw, issued) values
('2018-05-17', '旅費交通費', '現金', '公共交通機関', '新小岩<->新宿 @302x2', 604, 1),
('2018-05-17', '通信費', '現金', '葛飾郵便局', 'レターパックライト', 360, 1),
('2018-05-17', '旅費交通費', '現金', '公共交通機関', '四ツ木<->浅草 @328x2', 656, 1);
