<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <title>課題 - ハンズオン</title>
  <link rel="stylesheet" href="handson.css">
</head>

<body>

  <table>
    <tr>
      <th>日付</th>
      <th>借方科目</th>
      <th>貸方科目</th>
      <th>相手先</th>
      <th>摘要</th>
      <th>出金</th>
      <th>起票</th>
    </tr>
<?php

/*
    prototype.html からこのプログラム部分だけを変更
    (ページタイトルも変更してはいます)
*/

  define ("SRVR", "localhost");    // サーバー次第
  define ("USER", "webho_user");
  define ("PSWD", "hello");
  define ("DTBS", "webho_db");

  function pln ($line) {
    printf ("%s\n", $line);
  }


  $mi = new mysqli (SRVR, USER, PSWD, DTBS);

  $result = $mi->query (
    "select date, debit, credit, destination, summary, withdraw, issued".
    " from expenses_memo".
    " order by id"
  );
  while ($row = $result->fetch_row()) {
    pln ("    <tr>");
/*
    データベース内容をそのまま出力 / 編集不可バージョン
    pln ("      <td>{$row[0]}</td>");
    pln ("      <td>{$row[1]}</td>");
    pln ("      <td>{$row[2]}</td>");
    pln ("      <td>{$row[3]}</td>");
    pln ("      <td>{$row[4]}</td>");
    pln ("      <td>{$row[5]}</td>");
    pln ("      <td><input type='checkbox'".($row[6] == 1 ? " checked" : "")."></td>");
*/
    for ($i=0; $i<6; $i++)
      pln ("      <td><input type='text' value='{$row[$i]}'></td>");
    pln ("      <td><input type='checkbox'".($row[6] == 1 ? " checked" : "")."></td>");
    pln ("    </tr>");
  }

  $mi->close();

?>
  </table>

</body>
</html>
