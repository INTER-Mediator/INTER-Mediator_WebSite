<?php

//  複数ファイルから使えるように定数部を切り出し

define ("SRVR", "localhost");
define ("USER", "webho_user");
define ("PSWD", "hello");
define ("DTBS", "webho_db");


//  SQLite データベースファイル

define ("DB_FILE", "webho.db");


//  PDO DSN

$myDSN = "mysql:host=".SRVR.";dbname=".DTBS;
$liteDSN = "sqlite:".DB_FILE;

?>
