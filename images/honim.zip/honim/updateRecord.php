<?php

//  データ更新
//  prepared statement を使うともっとシンプルだがこれでも可という例として

require_once ("consts.php");

$value = $_POST["value"];
if ($_POST["col"] != "withdraw" && $_POST["col"] != "issued")
	$value = "'{$value}'";


$mi = new mysqli (SRVR, USER, PSWD, DTBS);
$mi->query (
	"update expenses_memo".
	" set ".$_POST["col"]."={$value}".
	" where id=".$_POST["id"]
);
$mi->close();


/*
//  SQLite
$db = new SQLite3 (DB_FILE);
$db->exec (
	"update expenses_memo".
	" set ".$_POST["col"]."={$value}".
	" where id=".$_POST["id"]
);
$db->close();
*/


/*
//  PDO
$dbh = new PDO ($myDSN, USER, PSWD);
// $dbh = new PDO ($liteDSN);
$dbh->exec (
	"update expenses_memo".
	" set ".$_POST["col"]."={$value}".
	" where id=".$_POST["id"]
);
$dbh = null;
*/
?>
