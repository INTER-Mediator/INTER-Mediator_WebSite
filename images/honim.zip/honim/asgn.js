//  Web サービスとしてデータベースアクセス

function deleteRecord (id) {
	var request = getRequest ("deleteRecord");
	if (request != null)
		request.send ("id="+id);
}

function addRecord () {
	var request = getRequest ("insertRecord");
	if (request != null)
		request.send();
}

function updateRecord (id, col, value) {
	var request = getRequest ("updateRecord");
	if (request != null)
		request.send (
			"id=" + id +
			"&col=" + col +
			"&value=" + value
		);
}

function updateIssued (target, id) {
	updateRecord (id, "issued", target.checked ? 1 : 0);
}

function getRequest (serviceName) {
	var request = null;

	try {
		request = new ActiveXObject ("Msxml2.XMLHTTP");
	} catch (e) {
		try {
			request = new ActiveXObject ("Microsoft.XMLHTTP");
		} catch (e) {
			try {
				request = new XMLHttpRequest();
			} catch (e) {}
		}
	}

	if (request != null) {
		request.onreadystatechange = loadedService;
		request.open ("POST", serviceName+".php", true);
		request.setRequestHeader ("Content-Type", "application/x-www-form-urlencoded");
	}

	return	request;
}

function loadedService (event) {
	//  データ取得完了後は一様にページをリロード
	var request = event.target;
	if (request.readyState == 4 && request.status == 200)
		location.reload (true);
}
