<?php

//  データ削除

require_once ("consts.php");

$mi = new mysqli (SRVR, USER, PSWD, DTBS);
$mi->query ("delete from expenses_memo where id=".$_POST["id"]);
$mi->close();

/*
//  SQLite
$db = new SQLite3 (DB_FILE);
$db->exec ("delete from expenses_memo where id=".$_POST["id"]);
$db->close();
*/

/*
//  PDO
$dbh = new PDO ($myDSN, USER, PSWD);
// $dbh = new PDO ($liteDSN);
$dbh->exec ("delete from expenses_memo where id=".$_POST["id"]);
$dbh = null;
*/

?>
