//  定数として

var cols = [
	"date",
	"debit",
	"credit",
	"destination",
	"summary",
	"withdraw"
];


//  グローバル変数
/*
    pageRows が 1 ページに表示する件数
    プログラム的な変更の他、UI で変更可能にすることを想定し定数ではなく変数で宣言
*/

var pageRows = 10;
var rowCount = 0;
var endRow = 0;


//  関数 (上書きにより既存の関数を変更)

function updateRecord (id, col, value) {
	var request = getRequest ("updateRecord");
	if (request != null) {
		request.reload = false;  // 変更点
		request.send (
			"id=" + id +
			"&col=" + col +
			"&value=" + value
		);
	}
}

function getRequest (serviceName) {
	var request = null;

	try {
		request = new ActiveXObject ("Msxml2.XMLHTTP");
	} catch (e) {
		try {
			request = new ActiveXObject ("Microsoft.XMLHTTP");
		} catch (e) {
			try {
				request = new XMLHttpRequest();
			} catch (e) {}
		}
	}

	if (request != null) {
		request.onreadystatechange = loadedService;
		request.open ("POST", serviceName+".php", true);
		request.setRequestHeader ("Content-Type", "application/x-www-form-urlencoded");
		request.reload = true;  // 変更点
	}

	return	request;
}

function loadedService (event) {
	var request = event.target;
	if (request.readyState == 4 && request.status == 200)  // ここ以下が変更点
		if (request.reload)
			dataReload();
}


//  関数 (追加分)

function dataReload () {
	var page = pgnavi.value;

	if (page == "" || page == null || page == undefined)
		pgnavi.value = 1;

	tab.innerHTML = headRow();

	var request = getRequest ("selectRecord");
	if (request != null) {
		request.reload = false;
		request.onreadystatechange = loadTableRows;
		request.send ("info=true");
	}
}

function headRow () {
	var cols = "";

	cols += "<tr>";
	cols += "<th>日付</th>";
	cols += "<th>借方科目</th>";
	cols += "<th>貸方科目</th>";
	cols += "<th>相手先</th>";
	cols += "<th>摘要</th>";
	cols += "<th>出金</th>";
	cols += "<th>起票</th>";
	cols += "<th></th>";
	cols += "</tr>";

	return	cols;
}

function loadTableRows (event) {
	var request = event.target;
	if (request.readyState == 4 && request.status == 200) {
		rowCount = request.response;
		pgview.innerHTML = " / " + rowCount;

		request = getRequest ("selectRecord");
		if (request != null) {
			var page = pgnavi.value;
			request.reload = false;
			request.start = (page - 1) * pageRows + 1;
			request.onreadystatechange = loadedRows;
			request.responseType = "text";
			request.send (
				"start=" + request.start +
				"&rows=" + pageRows
			);
		}
	}
}

function loadedRows (event) {
	var request = event.target;
	if (request.readyState != 4 || request.status != 200)
		return;

	var lines = request.response.split ("\n");
	var startRow = request.start;
	var retRowCnt = lines.length / 8;
	endRow = startRow + retRowCnt - 1;

	for (var i=0; i<retRowCnt; i++) {
		var pg = i * 8;
		var id = lines[pg];
		var rowstr;

		rowstr = "<tr>";
		for (var j=0; j<6; j++)
			rowstr += "<td><input type='text' value='" +
				lines[pg+j+1] +
				"' onchange=\"updateRecord(" +
				id +
				",'" +
				cols[j] +
				"',this.value)\"></td>";
		rowstr += "<td><input type='checkbox'";
		rowstr += lines[pg+7] == 1 ? " checked" : "";
		rowstr += " onchange='updateIssued(this," + id + ")'></td>";
		rowstr += "<td><button onclick='deleteRecord(" + id + ")'>削除</button></td>";
		rowstr += "</tr>";

		tab.innerHTML += rowstr;
	}

	pgview.innerHTML = startRow + " - " + endRow + pgview.innerHTML;
	checkPageNavi();
}

function checkPageNavi () {
	var page = pgnavi.value;

	if (page < 2) {
		pgnavi.value = 1;
		pageTop.disabled = true;
		pagePre.disabled = true;
	} else {
		pageTop.disabled = false;
		pagePre.disabled = false;
	}

	if (endRow < rowCount) {
		pageEnd.disabled = false;
		pageNxt.disabled = false;
	} else {
		pageEnd.disabled = true;
		pageNxt.disabled = true;
	}

	var pageMax = Math.floor (rowCount / pageRows);
	if (rowCount % pageRows > 0)
		pageMax++;
	pgnavi.max = pageMax;

	if (pageMax > 1)
		pgnavi.disabled = false;
	else
		pgnavi.disabled = true;
}

function pageToFirst () {
	pgnavi.value = 1;
	dataReload();
}

function pageToLast () {
	var lastPage = Math.floor (rowCount / pageRows);
	if (rowCount % pageRows > 0)
		lastPage++;
	pgnavi.value = lastPage;
	dataReload();
}

function pageToPrev () {
	pgnavi.value--;
	dataReload();
}

function pageToNext () {
	pgnavi.value++;
	dataReload();
}
