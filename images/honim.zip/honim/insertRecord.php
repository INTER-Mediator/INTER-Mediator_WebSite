<?php

//  データ追加

require_once ("consts.php");

$mi = new mysqli (SRVR, USER, PSWD, DTBS);
$mi->query ("insert into expenses_memo (issued) values (1)");
$mi->close();

/*
//  SQLite
$db = new SQLite3 (DB_FILE);
$db->exec ("insert into expenses_memo (issued) values (1)");
$db->close();
*/

/*
//  PDO
$dbh = new PDO ($myDSN, USER, PSWD);
// $dbh = new PDO ($liteDSN);
$dbh->exec ("insert into expenses_memo (issued) values (1)");
$dbh = null;
*/
?>
