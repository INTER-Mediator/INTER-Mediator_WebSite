<?php

//  データ読み込み

require_once ("consts.php");


if (isset($_POST["info"]) && $_POST["info"] == "true")
	$info = true;
else
	$info = false;


$mi = new mysqli (SRVR, USER, PSWD, DTBS);

if ($info) {
	//  info=true で呼び出されたら件数を出力
	$result = $mi->query ("select count(*) from expenses_memo");
	$row = $result->fetch_row();
	print $row[0];
	$result->free();
} else {
	$start = $_POST["start"] - 1;
	$rows = $_POST["rows"];

	$result = $mi->query (
		"select id, date, debit, credit, destination, summary, withdraw, issued".
		" from expenses_memo".
		" order by id".
		" limit {$rows} offset {$start}"
	);

	//  出力は REST が最適だろうが､今回は < > なども入っているので手抜き
	$isFirst = true;
	while ($row = $result->fetch_row()) {
		if ($isFirst)
			$isFirst = false;
		else
			print "\n";
		print implode ("\n", $row);
	}
	$result->free();
}

$mi->close();


/*
//  SQLite を使う

$db = new SQLite3 (DB_FILE);

if ($info) {
	$result = $db->query ("select count(*) from expenses_memo");
	$row = $result->fetchArray (SQLITE3_NUM);
	print $row[0];
	$result->finalize();
} else {
	$start = $_POST["start"] - 1;
	$rows = $_POST["rows"];

	$result = $db->query (
		"select id, date, debit, credit, destination, summary, withdraw, issued".
		" from expenses_memo".
		" order by id".
		" limit {$rows} offset {$start}"
	);

	$isFirst = true;
	while ($row = $result->fetchArray(SQLITE3_NUM)) {
		if ($isFirst)
			$isFirst = false;
		else
			print "\n";
		print implode ("\n", $row);
	}
	$result->finalize();
}

$db->close();
*/

/*
//  PDO による接続

$dbh = new PDO ($myDSN, USER, PSWD);
// $dbh = new PDO ($liteDSN);

if ($info) {
	$sth = $dbh->query ("select count(*) from expenses_memo");
	$row = $sth->fetch (PDO::FETCH_NUM);
	print $row[0];
} else {
	$start = $_POST["start"] - 1;
	$rows = $_POST["rows"];

	$sth = $dbh->query (
		"select id, date, debit, credit, destination, summary, withdraw, issued".
		" from expenses_memo".
		" order by id".
		" limit {$rows} offset {$start}"
	);

	$isFirst = true;
	while ($row = $sth->fetch (PDO::FETCH_NUM)) {
		if ($isFirst)
			$isFirst = false;
		else
			print "\n";
		print implode ("\n", $row);
	}
}

$sth = null;
$dbh = null;
*/
?>
