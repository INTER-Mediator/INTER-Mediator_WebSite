<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <title>課題 - ハンズオン</title>
  <link rel="stylesheet" href="handson.css">
  <script src="asgn.js"></script><!--  課題5 で追加  -->
</head>

<body>

  <table>
    <tr>
      <th>日付</th>
      <th>借方科目</th>
      <th>貸方科目</th>
      <th>相手先</th>
      <th>摘要</th>
      <th>出金</th>
      <th>起票</th>
      <th></th><!--  課題5 で追加  -->
    </tr>
<?php

  require_once ("consts.php");

  $cols = [
    "date",
    "debit",
    "credit",
    "destination",
    "summary",
    "withdraw",
  ];

  function pln ($line) {
    printf ("%s\n", $line);
  }


  $mi = new mysqli (SRVR, USER, PSWD, DTBS);

  //  美しくないが､プログラムの変更部を減らすために SQL を修正
  $result = $mi->query (
    "select date, debit, credit, destination, summary, withdraw, issued, id".
    " from expenses_memo".
    " order by id"
  );
  while ($row = $result->fetch_row()) {
    pln ("    <tr>");
    for ($i=0; $i<6; $i++)
      pln ("      <td><input type='text' value='{$row[$i]}'".
        " onchange=\"updateRecord({$row[7]},'{$cols[$i]}',this.value)\"></td>");
    pln ("      <td><input type='checkbox'".($row[6] == 1 ? " checked" : "").
      " onchange='updateIssued(this,{$row[7]})'></td>");
    pln ("      <td><button onclick='deleteRecord({$row[7]})'>削除</button></td>");
    pln ("    </tr>");
  }

  $mi->close();

?>
  <tr>
    <td colspan="8">
      <button onclick="addRecord()">追加</button>
    </td>
  </tr>
  </table>

</body>
</html>
